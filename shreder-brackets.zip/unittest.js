define(function (require, exports, module) {
    "use strict";
    var main = require("main");
    
    // tested. but not yet commited.

});